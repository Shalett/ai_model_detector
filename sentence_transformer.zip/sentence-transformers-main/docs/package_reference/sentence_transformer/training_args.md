# Training Arguments

## SentenceTransformerTrainingArguments

```{eval-rst}
.. autoclass:: sentence_transformers.training_args.SentenceTransformerTrainingArguments
    :members:
    :inherited-members:
```
