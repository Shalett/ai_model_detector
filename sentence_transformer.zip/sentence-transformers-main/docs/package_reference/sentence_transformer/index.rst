
Sentence Transformer
====================

.. toctree::

   SentenceTransformer
   trainer
   training_args
   losses
   sampler
   evaluation
   datasets
   models
   quantization