# Training Arguments

## CrossEncoderTrainingArguments

```{eval-rst}
.. autoclass:: sentence_transformers.cross_encoder.training_args.CrossEncoderTrainingArguments
    :members:
    :inherited-members:
```
