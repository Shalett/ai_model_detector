# Callbacks

## SpladeRegularizerWeightSchedulerCallback

```{eval-rst}
.. autoclass:: sentence_transformers.sparse_encoder.callbacks.splade_callbacks.SpladeRegularizerWeightSchedulerCallback
```
