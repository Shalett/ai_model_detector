Sparse Encoder
=============

.. toctree::

   SparseEncoder
   trainer
   training_args
   losses
   ../sentence_transformer/sampler
   evaluation
   models
   callbacks
   search_engines