# Training Arguments

## SparseEncoderTrainingArguments
```{eval-rst}
.. autoclass:: sentence_transformers.sparse_encoder.training_args.SparseEncoderTrainingArguments
   :members:
   :inherited-members:
``` 