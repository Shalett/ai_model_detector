.. sidebar:: Export, Optimize, and Quantize Hugging Face models

   This Hugging Face Space provides a user interface for exporting, optimizing, and quantizing models for either ONNX or OpenVINO:

   - `sentence-transformers/backend-export <https://huggingface.co/spaces/sentence-transformers/backend-export>`_
